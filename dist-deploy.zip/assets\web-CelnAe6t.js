import { W as WebPlugin } from "./index-B9IF2O2b.js";
import "./react-core-B1rSPtcn.js";
import "./icons-Be6fsX7F.js";
import "./maptiler-CuqeBaum.js";
import "./qr-PoIushue.js";
class SplashScreenWeb extends WebPlugin {
  async show(_options) {
    return void 0;
  }
  async hide(_options) {
    return void 0;
  }
}
export {
  SplashScreenWeb
};
